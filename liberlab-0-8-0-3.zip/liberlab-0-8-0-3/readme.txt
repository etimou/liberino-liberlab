
Liberlab is a Free Software released under the GPL licence (see the gpl-licence in the folder).

More informations about liberlab here:

www.liberlab.net


Liberlab software use the serial module to communicate with the liberlab board.
Look in the serial folder for the licence and author of this fine Python module (Python Software Foundation License).

You will need to install the Python programming lanquage to use Liberlab:
http://www.python.org/download/



Launch Liberlab for windows:
-----------------------------
Just double click on the liberlab-windows.pyw


Launch Liberlab for Linux:
-----------------------------
In a shell: python liberlab-linux.pyw

Never tried on Mac OS X but liberlab-linux.pyw should work.


Languages:
----------

Liberlab software is internationalized (english and french for the moment).
If your OS is in french it will appear in french and in english otherwise.
If you want to translater it in an other language there is a .po file in the locale folder (don't hesitate to contact me for help). 



---
francois schnell - ULP Multimedia
http://www.liberlab.net
francois.schnell@gmail.com
francois.schnell@ulpmm.u-strasbg.fr





