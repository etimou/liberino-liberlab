#*****************************************************************************
#!/usr/bin/env python
# Liberlab  (using atmega8 UART) 
# francois schnell - University Louis-Pasteur (ULP Multimedia)
# Thanks to my department for allowing me to work part of my working time
# on the project in addition to my free time work.
#
# using module pyserial: pyserial.sourceforge.net (to install)
#---
#  This program is free software; you can redistribute it and/or modify
#    it under the terms of the GNU General Public License as published by
#    the Free Software Foundation; either version 2 of the License, or
#    (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU General Public License for more details.
#
#    You should have received a copy of the GNU General Public License
#    along with this program; if not, write to the Free Software
#    Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
#
#*******************************************************************************
# Few info about the firmware:
# sends line of 21 chars with A1**A2**A3**A4** and IN*
# Two chars for each 10 bits channel value
# One char for the input status
# PC to microcontroller
# 6 outputs: 1 ("A" up , "a" down) until 6 ("F" up, "f" down)
# (repeat the char 3 times in a row to be on the safe side)
#******************************************************************************
# This was my first Python app and it's very procedural. 
# I've now done a nice and easy OO liberlab module (check www.liberlab.net)
# I plan to rewrite this app using the liberlab module and WxPython
#******************************************************************************


import sys, os, time, datetime, serial, math, struct, tkMessageBox, tkFileDialog, gettext
from Tkinter import *
from math import *
from random import randrange
from os import chdir


# Part of the variables used in the program
global port, baudrate, echo, rtscts, xonxoff, repr_mode, valuelength

# Initial serial port setting
port  = 0
baudrate = 57600 # Liberlab firmware works at 57600 Bauds
echo = 0
rtscts = 0
xonxoff = 0
repr_mode = 1
# a1 means analogic chanel 1, (x1 and y1 are coordinates) : used for analogic graphical display
a1x1, a1y1, a2x1, a2y1, a3x1, a3y1, a4x1, a4y1, a5x1, a5y1, a6x1, a6y1 = 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
valuelength= 21 # Expected length line sent by the microcontroller
countrecord=1 # Analogic channel recording counter

#--------- i18n settings --------------------------------------------------------

localedir= "locale"
gettext.install("liberlab-soft", localedir)
#gettext.install("liberlab-soft", localedir, unicode=False)

# -------- open the serial port now  --------------------------------------------
try:
    global s
    s = serial.Serial(port, baudrate, rtscts=rtscts, xonxoff=xonxoff, timeout=1)
    print _("Serial port open :) ")
except:
    #sys.stderr.write(_("Could not open port  :( \n"))
    #sys.exit(1)
    port = "/dev/ttyUSB0"
    s = serial.Serial(port, baudrate, rtscts=rtscts, xonxoff=xonxoff, timeout=1)    
sys.stderr.write(_("--- Liberlab Feedback  ---"))

# ----  Few functions ----------

def exitapp():
    """ Exit Liberlab properly and close serial plug"""
    s.close(); fen1.quit(); fen1.destroy()

def Denary2Binary(n):
    """convert denary integer n to binary string bStr"""
    # Used to read the inputs register of the microcontrolleur(each bit is an input)
    bStr = ''
    if n < 0:  raise ValueError, "must be a positive integer"
    if n == 0: return '0'
    while n > 0:
        bStr = str(n % 2) + bStr
        n = n >> 1
    return bStr

## --------  Reading  Analogic values ----------------------------------------------------------------------------
def measure(): 
    """ Serial acquisition and interpretation """
    global  ready, valuelength, adcchoice1, adcchoice2, adcchoice3, adcchoice4, adcchoice5, adcchoice6, t1, t0
    global tension1, tension2, tension3, tension4, physValue1; physValue2, physValue3, physValue4, formula1, formula2, formula3, formula4
    global physShow1, physShow2, physShow3, physShow4, resolution1, resolution2, resolution3, resolution4
    # adcchoice1 to adcchoice6 represent the value of the analogic choice checkbuttons
    s.write("yyy")  #just a wakeup call in case off
    t0=time.time() # For Linux version ( time.clock for windows verion)
    ready = 1
    t1= time.time() # For Linux version ( time.clock for windows verion)
    # Test if there is some traffic on the serial line:
    value= s.readline() # reads a line in the serial buffer
    if len(value)==0:
        tkMessageBox.showwarning(_("Serial Port Message"),_("No Liberlab data detected on serial port"))
        s.flushInput()
    refreshdisplay()    
    while ready == 1:
            value= s.readline() # reads a line in the serial buffer                    
            if  len(value)==valuelength and (((time.time()-t1)) >= float(displayspeed.get()/100.0) - 0.01)  :             
                # search analogic values in the string and interpret them
                if (adcchoice1.get()==1):
                    ADCH1= ord(value[value.find("A1")+2])*256 ; ADCL1= ord(value[value.find("A1")+3])
                    V1= (ADCL1 + ADCH1)*5.0/1024 ; tension1.set(round(V1,2))
                if (adcchoice2.get()==1):
                    ADCH2= ord(value[value.find("A2")+2])*256 ; ADCL2= ord(value[value.find("A2")+3])
                    V2= (ADCL2 + ADCH2)*5.0/1024 ; tension2.set(round(V2,2))
                if (adcchoice3.get()==1):
                    ADCH3= ord(value[value.find("A3")+2])*256 ; ADCL3= ord(value[value.find("A3")+3])
                    V3= (ADCL3 + ADCH3)*5.0/1024 ; tension3.set(round(V3,2))
                if (adcchoice4.get()==1):
                    ADCH4= ord(value[value.find("A4")+2])*256 ; ADCL4= ord(value[value.find("A4")+3])
                    V4= (ADCL4 + ADCH4)*5.0/1024 ; tension4.set(round(V4,2))
                # search the input char in the string and interpret them
                inputsstate= Denary2Binary(ord(value[value.find("IN")+2])) 
                istate= (6-len(inputsstate))*"0"  + inputsstate  # add the necessary 0 to have 6 binary data
                #print istate
                for i in (0,1,2,3,4,5):
                    if (istate[i]=="1"):
                        E[i].configure(bg="green")
                    else:
                        E[i].configure(bg="grey")      
                # Physical Values evaluation
                if physShow1==1 & (formula1 != ""):
                        P1=float(eval(formula1))
                        physValue1.set(round(P1,resolution1))
                if physShow2==1 & (formula2 != ""):
                        P2=float(eval(formula2))
                        physValue2.set(round(P2,resolution2))
                if physShow3==1 & (formula3 != ""):
                        P3=float(eval(formula3))
                        physValue3.set(round(P3,resolution3))
                if physShow4==1 & (formula4 != ""):
                        P4=float(eval(formula4))
                        physValue4.set(round(P4,resolution4))
                #Outputs automations
                if automation1 ==1 & (formulauto1 !=""):
                    if eval(formulauto1)==True :
                        s.write("AAA")
                    else:
                        s.write("aaa")
                if automation2 ==1 & (formulauto2 !=""):
                    if eval(formulauto2)==True:
                        s.write("BBB")
                    else:
                        s.write("bbb")
                if automation3 ==1 & (formulauto3 !=""):
                    if eval(formulauto3)==True:
                        s.write("CCC")
                    else:
                        s.write("ccc")
                if automation4 ==1 &(formulauto4 !=""):
                    if eval(formulauto4)==True:
                        s.write("DDD")
                    else:
                        s.write("ddd")
                if automation5 ==1 &(formulauto5 !=""):
                    if eval(formulauto5)==True:
                        s.write("EEE")
                    else:
                        s.write("eee")
                if automation6 ==1 &(formulauto6 !=""):
                    if eval(formulauto6)==True:
                        s.write("FFF")
                    else:
                        s.write("fff")
                
                drawdata()     # Draw analogic channels on the canevas
                s.flushInput() # Flush the serial buffer
                can1.update()  # Refresh the canevas
                t1= time.time()
            else:
                can1.update()  # Refresh the canevas

# Interpretation of a physical value from the voltage one (argument)
def physicalvalue1(x): 
    return math.floor(15*x)

# -------------------    graphical display of ADC input and control -----------------------------------
def refreshdisplay():
    global a1x1,a2x1,a3x1,a4x1, t1
    a1x1,a2x1,a3x1,a4x1=0,0,0,0; can1.delete(ALL)
    display_patern()
    
# Draw data on canvas and if asked write them in a file
def drawdata():  
    "draw analogic channels"
    global a1x1, a1y1, a1x2, a1y2, a2x1, a2y1, a2x2, a2y2, coul, enregistre, enregistrePhys, t0, countrecord,\
           a3x1, a3y1, a3x2, a3y2, a4x1, a4y1, a4x2, a4y2,a5x1, a5y1, a5x2, a5y2, a6x1, a6y1, a6x2, a6y, \
           physValue1, physValue2, physValue3, physValue4
    if (adcchoice1.get()==1):
        a1y2= canvas_height - ((float(tension1.get())*canvas_height)/5)-1
        can1.create_line(a1x1, a1y1, a1x1+1, a1y2,width=1,fill='white'); a1x1=a1x1+1
        tensionmesuree1= float(tension1.get()); a1y1= canvas_height - ((tensionmesuree1*canvas_height)/5)-1
    if (adcchoice2.get()==1):
        a2y2= canvas_height - ((float(tension2.get())*canvas_height)/5)-1
        can1.create_line(a2x1, a2y1, a2x1+1, a2y2,width=1,fill='red' ); a2x1=a2x1+1
        tensionmesuree2= float(tension2.get()); a2y1= canvas_height - ((tensionmesuree2*canvas_height)/5)-1
    if (adcchoice3.get()==1):
        a3y2= canvas_height - ((float(tension3.get())*canvas_height)/5)-1
        can1.create_line(a3x1, a3y1, a3x1+1, a3y2,width=1,fill='yellow' ); a3x1=a3x1+1
        tensionmesuree3= float(tension3.get()); a3y1= canvas_height - ((tensionmesuree3*canvas_height)/5)-1
    if (adcchoice4.get()==1):
        a4y2= canvas_height - ((float(tension4.get())*canvas_height)/5)-1
        can1.create_line(a4x1, a4y1, a4x1+1, a4y2,width=1,fill='blue'); a4x1=a4x1+1
        tensionmesuree4= float(tension4.get()); a4y1= canvas_height - ((tensionmesuree4*canvas_height)/5)-1
    if (a1x1 or a2x1 or a3x1 or a4x1) > canvas_width: # Delete objects on the canevas go back left
        refreshdisplay()
        display_patern()

    if (enregistre ==1) & (t1-t0>0):
        enregistrement.write(str(countrecord)+ ", ")    
        enregistrement.write(str(round(t1-t0,3))+ ", ")
        if (adcchoice1.get()==1):
            enregistrement.write(str(tensionmesuree1)+", ")
        if (adcchoice2.get()==1):
            enregistrement.write(str(tensionmesuree2)+", ")
        if (adcchoice3.get()==1):
            enregistrement.write(str(tensionmesuree3)+", ")
        if (adcchoice4.get()==1):
            enregistrement.write(str(tensionmesuree4)+", ")
        if physShow1==1:
            enregistrement.write(physValue1.get()+", ")
        else:
            enregistrement.write((" *, "))
        if physShow2==1:
            enregistrement.write(physValue2.get()+", ")
        else:
            enregistrement.write((" *, "))
        if physShow3==1:
            enregistrement.write(physValue3.get()+", ")
        else:
            enregistrement.write((" *, "))      
        if physShow4==1:
            enregistrement.write(physValue4.get()+", ")
        else:
            enregistrement.write((" *, "))
  
        enregistrement.write("\n")
            
        countrecord +=1

def display_patern():  
    for i in (0,1,2,3,4,5):
        can1.create_line(0, i*(canvas_height/5), canvas_width, i*(canvas_height/5),width=1,\
                         fill='light grey', stipple='gray25')
    for i in (0,1,2,3,4):
        can1.create_text( canvas_width - 20, (5-i)*(canvas_height/5)-5, text=str(i) + " V", fill='light grey' )
    
# Pause in the display of data
def displaystandby():
    global  ready
    ready=2

# Read value-clic on the canvas (plots) and send result to bottom label
def pointeur(event):
    tension= 5.0*(canvas_height - event.y)/canvas_height
    labeletat.configure(text= "..." + _("Voltage here =  ") + str(tension) + " Volts      ")   

# ------------------------------  Recording of ADC input ---------------------------------------------
# Engage recording in a file
def enregistrer():
    bouenregistre.configure(relief=SUNKEN, fg="red")
    global enregistrement # the recording file object
    global countrecord # To affect a number to each value recorded
    global enregistre # To inform the rest of the program if we are recording
    global t0 #CPU time for the first value recorded
    date=time.localtime()[7] # to know the date number in the year

    myFormats = [('csv','*.csv'),]  
    fileName = tkFileDialog.asksaveasfilename(parent=fen1,filetypes=myFormats ,title="Save")
    #filename= "C:/liberlabdatas/test.csv"
    enregistrement=open(fileName + "",'w') # Linux version: took + ".csv" off
    #enregistrement.write("Date (day of the year): " + str(date)+ "\n")
    enregistrement.write("n, t (s), V1, V2, V3, V4, f1, f2, f3, f4 \n")
    #enregistrement.write("Intervalle d'acquisition initial (0 means maxi): "+ str(displayspeed.get()/100.0) +"\n")
    t0=time.time() # For Linux version ( time.clock for windows verion)
    enregistre=1
    #compt=1
    countrecord = 1
    
    # End the recording in a file

def finenregistrer():
    global enregistre
    bouenregistre.configure(relief=RAISED, fg="black")
    enregistre=0
    enregistrement.close()


#------------ Options Window -----------------------------------------------

# Lauch this window when Button Options is hit from menubar
def  options():
    global fenOptions, valueBauds, NumberOfADCchannels, valuePort
    fenOptions=Tk()
    fenOptions.title("Options")
    labelPorts=Label(fenOptions,text=_('Serial Port:'))
    textBauds=Label(fenOptions,text=_('Serial data speed (Bauds):'))
    textBauds2=Label(fenOptions,text=_('Current value :') + str(baudrate), fg='white')
    currentPort=Label(fenOptions,text=_('Current port :') + str(port), fg='white')
    valuePort=Entry(fenOptions, text=port)
    valueBauds=Entry(fenOptions, text=baudrate)
    bouValider=Button(fenOptions, width=15, text=_('Apply'), command=validerOptions)
    bouAnnuler=Button(fenOptions, width=15, text=_('Cancel'),command=quitterOptions)
    labelPorts.pack(pady=5)
    valuePort.pack(pady=8)
    currentPort.pack()
    textBauds.pack(pady=10)
    valueBauds.pack(pady=8)
    textBauds2.pack(pady=5)
    bouValider.pack(side=LEFT)
    bouAnnuler.pack(side=RIGHT)
    
# Validate options choices
def validerOptions():
    global valueBauds,valuePort, baudrate, s, port, rtscts,xonxoff
    if (valueBauds.get() != ""):
        baudrate=valueBauds.get()
    if (valuePort.get() != ""):
        port=valuePort.get()
    try:
        s.close()
        s = serial.Serial(port, baudrate, rtscts=rtscts, xonxoff=xonxoff)
    except:
        sys.stderr.write(_("Could not open port  :( \n"))
        sys.exit(1)
    print _("Serial Port Open")
    print _("Bauds speed set at: "),  baudrate
    print _("Current serial port tested: "), port 
    fenOptions.destroy()

# When Quitting / cancelling Options window
def quitterOptions():
    fenOptions.destroy()
    
#-------------- About Window    -------------------------------------------------
 
#About window
def  about():
    #fenAbout=Tk()
    global fenAbout
    fenAbout=Toplevel()
    fenAbout.title(_("About"))
    buOk=Button(fenAbout, text="Ok", width= 10, command=quitterAbout)
    frame1= Frame(fenAbout, borderwidth=3, relief=SUNKEN, bg="white", colormap="new")
    frame2= Frame(fenAbout, bg="white", colormap="new")
    frame1.pack()
    frame2.pack()
    Aboutlabel1 = Label (frame1, text=_("Liberlab Software"), bg="white", fg="red", pady=5).pack()
    Aboutlabel2 = Label (frame1, text="Francois Schnell - ULPMultimedia", bg="grey", fg="yellow").pack()
    Aboutlabel3 = Label (frame1, text="www.liberlab.net",  font=("Helvetica", 15), bg="white", pady=15, padx=15, fg="blue").pack()
    buOk.pack()
def quitterAbout():
    fenAbout.destroy()

# -------------- Digital Exits buttons ---------------------

def buto1():
    global butio1sunken
    if  (butio1sunken == False):  
        butio1.configure(fg="red", relief=SUNKEN)
        s.write("AAA")
        butio1sunken= True
        print "Message sent: output1 -> 1"
    else:
        butio1.configure(fg="black", relief=RAISED)
        s.write("aaa")
        butio1sunken= False
        print "Message sent: output1 -> 0"
def buto2():
    global butio2sunken
    if  (butio2sunken == False):  
        butio2.configure(fg="red", relief=SUNKEN)
        s.write("BBB")
        butio2sunken= True
        print "Message sent: output2 -> 1"
    else:
        butio2.configure(fg="black", relief=RAISED)
        s.write("bbb")
        butio2sunken= False
        print "Message sent: output2 -> 0"
def buto3():
    global butio3sunken
    if  (butio3sunken == False):  
        butio3.configure(fg="red", relief=SUNKEN)
        s.write("CCC")
        butio3sunken= True
        print "Message sent: output3 -> 1"
    else:
        butio3.configure(fg="black", relief=RAISED)
        s.write("ccc")
        butio3sunken= False
        print "Message sent: output3 -> 0"
def buto4():
    global butio4sunken
    if  (butio4sunken == False):  
        butio4.configure(fg="red", relief=SUNKEN)
        s.write("DDD")
        butio4sunken= True
        print "Message sent: output4 -> 1"
    else:
        butio4.configure(fg="black", relief=RAISED)
        s.write("ddd")
        butio4sunken= False
        print "Message sent: output4 -> 0"
def buto5():
    global butio5sunken
    if  (butio5sunken == False):  
        butio5.configure(fg="red", relief=SUNKEN)
        s.write("EEE")
        butio5sunken= True
        print "Message sent: output5 -> 1"
    else:
        butio5.configure(fg="black", relief=RAISED)
        s.write("eee")
        butio5sunken= False
        print "Message sent: output5 -> 0"
def buto6():
    global butio6sunken
    if  (butio6sunken == False):  
        butio6.configure(fg="red", relief=SUNKEN)
        s.write("FFF")
        butio6sunken= True
        print "Message sent: output6 -> 1"
    else:
        butio6.configure(fg="black", relief=RAISED)
        s.write("fff")
        butio6sunken= False
        print "Message sent: output6 -> 0"

#--------------------------------------------------------------------------------
def automation():
    global enterFomulauto1Entry, enterFomulauto2Entry, enterFomulauto3Entry,  enterFomulauto4Entry, \
    enterFomulauto5Entry, enterFomulauto6Entry,  windowAutomation
    windowAutomation=Toplevel()
    frame2=Frame(windowAutomation, borderwidth=3, relief=SUNKEN)
    frame3=Frame(windowAutomation, borderwidth=3, relief=SUNKEN)
    frame4=Frame(windowAutomation, borderwidth=3, relief=SUNKEN)
    frame2.grid(row=5, column=1)
    frame3.grid(row=10, column=1)
    frame4.grid(row=15, column=1)
    windowAutomation.title(_("Automation of digital outputs"))
    enterFomulautoLabel=Label(frame2,text=_('Enter conditions in funtion of V1, V2, V3 and/or V4:'), width=50, fg='black')
    emptyLabel=Label(frame2,text='')
    enterFomulauto1Label=Label(frame2,text=_('output1 ON if:'))
    enterFomulauto2Label=Label(frame2,text=_('output2 ON if:'))
    enterFomulauto3Label=Label(frame2,text=_('output3 ON if:'))
    enterFomulauto4Label=Label(frame2,text=_('output4 ON if:'))
    enterFomulauto5Label=Label(frame2,text=_('output5 ON if:'))
    enterFomulauto6Label=Label(frame2,text=_('output6 ON if:'))
    enterFomulauto1Entry=Entry(frame2,  width=12)
    enterFomulauto2Entry=Entry(frame2,  width=12)
    enterFomulauto3Entry=Entry(frame2,  width=12)
    enterFomulauto4Entry=Entry(frame2,  width=12)
    enterFomulauto5Entry=Entry(frame2,  width=12)
    enterFomulauto6Entry=Entry(frame2,  width=12)
    buValidate1=Button(frame2, width=10, text=_('Validate 1'), command=validatec1)
    buValidate2=Button(frame2, width=10, text=_('Validate 2'), command=validatec2)
    buValidate3=Button(frame2, width=10, text=_('Validate 3'), command=validatec3)
    buValidate4=Button(frame2, width=10, text=_('Validate 4'), command=validatec4)
    buValidate5=Button(frame2, width=10, text=_('Validate 5'), command=validatec5)    
    buValidate6=Button(frame2, width=10, text=_('Validate 6'), command=validatec6)
    buCancel=Button(frame4, width=30, text=_('Quit'),command=quitWindowAutomation)
    bou1=Button(frame4,text=_('Measure'),command=measure, width=8)
    bou1.grid(row=35, column=20)
    bou3=Button(frame4,text='Pause', command=displaystandby, width=8)
    bou3.grid(row=35, column=30)
    enterFomulautoLabel.grid(row=6, columnspan=40)
    emptyLabel.grid(row=7)
    enterFomulauto1Label.grid(row=8, column=5)
    enterFomulauto2Label.grid(row=8, column=10)
    enterFomulauto3Label.grid(row=8, column=15)
    enterFomulauto4Label.grid(row=8, column=20) 
    enterFomulauto5Label.grid(row=8, column=25)     
    enterFomulauto6Label.grid(row=8, column=30)    
    enterFomulauto1Entry.grid(row=10, column=5, padx=5)
    enterFomulauto2Entry.grid(row=10, column=10 , padx=5)
    enterFomulauto3Entry.grid(row=10, column=15 , padx=5)
    enterFomulauto4Entry.grid(row=10, column=20 , padx=5)
    enterFomulauto5Entry.grid(row=10, column=25 , padx=5)    
    enterFomulauto6Entry.grid(row=10, column=30 , padx=5)
    buValidate1.grid(row=15, column=5)
    buValidate2.grid(row=15, column=10)
    buValidate3.grid(row=15, column=15)
    buValidate4.grid(row=15, column=20)
    buValidate5.grid(row=15, column=25)
    buValidate6.grid(row=15, column=30)
    buCancel.grid(row=35, column=3)
def validatec1():
    global tension1,  formulauto1, automation1
    automation1 =1
    formulauto1= enterFomulauto1Entry.get()
def validatec2():
    global tension2,  formulauto2, automation2
    automation2 =1
    formulauto2= enterFomulauto2Entry.get()
def validatec3():
    global tension3,  formulauto3, automation3
    automation3 =1
    formulauto3= enterFomulauto3Entry.get()
def validatec4():
    global tension4,  formulauto4, automation4
    automation4 =1
    formulauto4= enterFomulauto4Entry.get()
def validatec5():
    global tension5,  formulauto5, automation5
    automation5 =1
    formulauto5= enterFomulauto5Entry.get()
def validatec6():
    global tension6,  formulauto6, automation6
    automation6 =1
    formulauto6= enterFomulauto6Entry.get()
def quitWindowAutomation():
    global automation1,automation2,automation3,automation4,automation5,automation6 
    automation1,automation2,automation3,automation4,automation5,automation6 = 0,0,0,0,0,0
    windowAutomation.destroy()
def SetPhysValue():
    global tension1, tension2, tension3, tension4, physValue1, physValue2, physValue3, physValue4, windowPhysValues
    global enterFomula1Entry, enterFomula2Entry, enterFomula3Entry, enterFomula4Entry, enregistrePhys
    physValue1.set('***')
    physValue2.set('***')
    physValue3.set('***')
    physValue4.set('***')
    
    windowPhysValues=Toplevel()

    frame2=Frame(windowPhysValues, borderwidth=3, relief=SUNKEN)
    frame3=Frame(windowPhysValues, borderwidth=3, relief=SUNKEN)
    frame4=Frame(windowPhysValues, borderwidth=3, relief=SUNKEN)
    frame2.grid(row=5, column=1)
    frame3.grid(row=10, column=1)
    frame4.grid(row=15, column=1)
    
    windowPhysValues.title(_("Physical values and on-the-fly computation"))
    enterFomulaLabel=Label(frame2,text=_('Enter the formulas depending of V1, V2, V3 and/or V4:'))
    enterFomula1Label=Label(frame2,text='f1(V1,V2,V3,V4)=')
    enterFomula2Label=Label(frame2,text='f2(V1,V2,V3,V4)=')
    enterFomula3Label=Label(frame2,text='f3(V1,V2,V3,V4)=')
    enterFomula4Label=Label(frame2,text='f4(V1,V2,V3,V4)=')
    
    enterFomula1Entry=Entry(frame2) 
    enterFomula2Entry=Entry(frame2)
    enterFomula3Entry=Entry(frame2)
    enterFomula4Entry=Entry(frame2)
    
    #enterFomula1Entry.insert(0,formula1)        
    buValidate1=Button(frame2, width=10, text=_('Validate f1'), command=validatePhysValue1)
    buValidate2=Button(frame2, width=10, text=_('Validate f2'), command=validatePhysValue2)
    buValidate3=Button(frame2, width=10, text=_('Validate f3'), command=validatePhysValue3)
    buValidate4=Button(frame2, width=10, text=_('Validate f4'), command=validatePhysValue4)
    
    buCancel=Button(frame4, width=30, text=_('Quit'),command=quitPhysValue1Window)

    #enterFomulaLabel.grid(row=5, column=10)

    bou1=Button(frame4,text=_('Measure'),command=measure, width=8)
    bou1.grid(row=35, column=20)
    bou3=Button(frame4,text='Pause', command=displaystandby, width=8)
    bou3.grid(row=35, column=30)

    enterFomula1Label.grid(row=8, column=5)
    enterFomula2Label.grid(row=8, column=10)
    enterFomula3Label.grid(row=8, column=15)
    enterFomula4Label.grid(row=8, column=20) 
    
    enterFomula1Entry.grid(row=10, column=5, padx=10)
    enterFomula2Entry.grid(row=10, column=10 , padx=10)
    enterFomula3Entry.grid(row=10, column=15 , padx=10)
    enterFomula4Entry.grid(row=10, column=20 , padx=10)

    buValidate1.grid(row=15, column=5)
    buValidate2.grid(row=15, column=10)
    buValidate3.grid(row=15, column=15)
    buValidate4.grid(row=15, column=20)

    PhysValue1Label= Label(frame3, textvariable=physValue1, font=("helvetica",14), fg='white', bg="grey", width=10, bd=5)
    PhysValue2Label= Label(frame3, textvariable=physValue2, font=("helvetica",14), fg='red', bg="grey", width=10, bd=5)
    PhysValue3Label= Label(frame3, textvariable=physValue3, font=("helvetica",14), fg='yellow', bg="grey", width=10, bd=5)
    PhysValue4Label= Label(frame3, textvariable=physValue4, font=("helvetica",14), fg='blue', bg="grey", width=10, bd=5)

    plus1But=Button(frame3,text='+', command=plus1)
    minus1But=Button(frame3,text='-', command=minus1)
    plus2But=Button(frame3,text='+', command=plus2)
    minus2But=Button(frame3,text='-', command=minus2)
    plus3But=Button(frame3,text='+', command=plus3)
    minus3But=Button(frame3,text='-', command=minus3)
    plus4But=Button(frame3,text='+', command=plus4)
    minus4But=Button(frame3,text='-', command=minus4)
    
    PhysValue1Label.grid(row=30, column=5 , padx=15)
    plus1But.grid(row=30, column=5 , sticky=W, padx=5 )
    minus1But.grid(row=30, column=5 ,sticky="e", padx=5 )
    PhysValue2Label.grid(row=30, column=10 , padx=15)
    plus2But.grid(row=30, column=10 , sticky=W, padx=5 )
    minus2But.grid(row=30, column=10 ,sticky="e", padx=5 )        
    PhysValue3Label.grid(row=30, column=15 , padx=15)
    plus3But.grid(row=30, column=15 , sticky=W, padx=5 )
    minus3But.grid(row=30, column=15 ,sticky="e", padx=5 )        
    PhysValue4Label.grid(row=30, column=20 , padx=15)
    plus4But.grid(row=30, column=20 , sticky=W, padx=5 )
    minus4But.grid(row=30, column=20 ,sticky="e", padx=5 )        
    
    buCancel.grid(row=35, column=3)

def minus1():
    global resolution1
    if resolution1 > 1:
        resolution1-=1
def plus1():
    global resolution1
    resolution1+=1
def minus2():
    global resolution2
    if resolution2 > 1:
        resolution2-=1
def plus2():
    global resolution2
    resolution2+=1
def minus3():
    global resolution3
    if resolution3 > 1:
        resolution3-=1
def plus3():
    global resolution3
    resolution3+=1
def minus4():
    global resolution4
    if resolution4 > 1:
        resolution4-=1
def plus4():
    global resolution4
    resolution4+=1
    
def validatePhysValue1():
    global tension1, physValue1, physShow1, formula1
    physShow1=1
    formula1= enterFomula1Entry.get()
def validatePhysValue2():
    global tension2, physValue2, physShow2, formula2
    physShow2=1
    formula2= enterFomula2Entry.get()
    print physShow2
    print formula2
def validatePhysValue3():
    global tension3, physValue3, physShow3, formula3
    physShow3=1
    formula3= enterFomula3Entry.get()    
def validatePhysValue4():
    global tension4, physValue4, physShow4, formula4
    physShow4=1
    formula4= enterFomula4Entry.get()
def quitPhysValue1Window():
    global windowPhysValues,physShow1, physShow2, physShow3, physShow4, physValue1, physValue2, physValue3, physValue4
    physShow1, physShow2, physShow3, physShow4 = 0,0,0,0
    physValue1.set('***')
    physValue2.set('***')
    physValue3.set('***')
    physValue4.set('***')
    
    windowPhysValues.destroy()

def Denary2Binary(n):
    '''convert denary integer n to binary string bStr'''
    bStr = ''
    if n < 0:  raise ValueError, "must be a positive integer"
    if n == 0: return '0'
    while n > 0:
        bStr = str(n % 2) + bStr
        n = n >> 1
    return bStr

#------------------- Main Window    ---------------------------------------------
global validgrandeur1, formula1, ready
physShow1, physShow2, physShow3, physShow4 = 0,0,0,0
formula1, formula2, formula3, formula4 = 1,1,1,1
resolution1, resolution2, resolution3, resolution4=2,2,2,2
global formulauto1, formulauto2, formulauto3, formulauto4,  formulauto5, formulauto6
formulauto1, formulauto2, formulauto3, formulauto4,  formulauto5, formulauto6= 1,1,1,1,1,1
global automation1, automation2, automation3, automation4, automation5, automation6
automation1, automation2, automation3, automation4, automation5, automation6 = 0,0,0,0,0,0
enregistre=0
enregistrePhys=0
ready=0
      
# GUI launch
fen1=Tk()
fen1.title("Liberlab software")

# The menu bar
menubar=Menu(fen1)
menubar.add_command(label="Options",command=options)
menubar.add_command(label=_("Physical values and computation"), command=SetPhysValue)
menubar.add_command(label=_("Automation"), command=automation)
menubar.add_command(label=_("About"), command=about)
fen1.config(menu=menubar)

#A canvas to plot the data (time in axis)
x1=0 ; canvas_height=500 ; canvas_width=600
can1=Canvas(fen1,bg='dark grey',height=canvas_height,width=canvas_width)
can1.grid(row=1, rowspan=20,column=1)
can1.bind("<Button-1>",pointeur)
display_patern()

# Voltage Labels  'in real time'
tension1,tension2,tension3,tension4 =StringVar(),StringVar(),StringVar(),StringVar()
physValue1, physValue2, physValue3, physValue4 = StringVar(),StringVar(),StringVar(),StringVar()
tension1label = Label(fen1, text=_('Measure of channel 1 (volts):'), padx=25)
tension1label.grid(row=1,column=2); tension1.set('***')
tension1Measurelabel = Label(fen1, textvariable=tension1, font=("helvetica",18), fg='white',bg="grey", width=10, bd=5)
tension1Measurelabel.grid(row=2, column=2)
# Physical value display if needed
# physique=StringVar(); physique.set('***')
tension2label = Label(fen1, text=_('Measure of channel 2 (volts):'), padx=25)
tension2label.grid(row=3,column=2); tension2.set('***')
tension2Measurelabel = Label(fen1, textvariable=tension2, font=("helvetica",18), fg='red', bg="grey", width=10, bd=5)
tension2Measurelabel.grid(row=4, column=2)
tension3label = Label(fen1, text=_('Measure of channel 3 (volts):'), padx=25)
tension3label.grid(row=5,column=2); tension3.set('***')
tension3Measurelabel = Label(fen1, textvariable=tension3, font=("helvetica",18), fg='yellow', bg="grey", width=10, bd=5)
tension3Measurelabel.grid(row=6, column=2)
tension4label = Label(fen1, text=_('Measure of channel 4 (volts):'), padx=25)
tension4label.grid(row=7,column=2); tension4.set('***')
tension4Measurelabel = Label(fen1, textvariable=tension4, font=("helvetica",18), fg='blue', bg="grey", width=10, bd=5)
tension4Measurelabel.grid(row=8, column=2)


#Buttons to control the measure
bou1=Button(fen1,text=_('Measure'),command=measure)
bou1.grid(row=10, sticky=W,column=2, padx=5)
bou3=Button(fen1,text='Pause', command=displaystandby)
bou3.grid(row=10, sticky=E, column=2, padx=5)
bou4=Button(fen1,text=_('Clear'), command=refreshdisplay)
bou4.grid(row=10, column=2, padx=5)

# Display and acquisition speed
displayspeed= Scale(fen1, length=250, orient=HORIZONTAL, label=_("Data capture speed (in 1/100 s)"), \
                   from_=0, to=6000)
displayspeed.grid(row=15, column=2, padx=5)

# A recorder display => file (2 buttons)

textenregistreur = Label(fen1, text=_('Recording in a file:'))
textenregistreur.grid(row=19, column=2)
bouenregistre=Button(fen1,text=_('Record'), command=enregistrer,width=7)
bouenregistre.configure(fg="red")
boustop=Button(fen1,text='Stop', command=finenregistrer,width=6)
bouenregistre.grid(row=20, column=2, sticky=W, padx=15)
boustop.grid(row=20, column=2, sticky=E, padx=15)

# A button to quit the app    
bou2=Button(fen1, width= 20, text=_('Quit'),command=exitapp)
bou2.grid(row=24, column=2)

# A state bar at the bottom of the window => click on the canvas ro read a value
labeletat= Label(fen1, text=_("Click on the graph to 'read' a voltage"), fg='grey')
labeletat.grid(row=22, columnspan=4, sticky=W)

# -----------  Frame at the bottom of the window  --------------------

frame1=Frame(fen1, borderwidth=3, relief=SUNKEN)
frame1.grid(row=24, column=1,sticky=W)

# Selection of ADC inputs to display
adctext= Label(frame1, text=_('Analogic channels selection:  ')).pack()

global  adcchoice1, adcchoice2, adcchoice3, adcchoice4
adcchoice1, adcchoice2, adcchoice3, adcchoice4 = IntVar(), IntVar(), IntVar(),IntVar()
        
adccheckbutton1= Checkbutton (frame1, text='1', variable=adcchoice1, command= refreshdisplay)
adccheckbutton1.pack(side=LEFT); adccheckbutton1.select()
adccheckbutton2= Checkbutton (frame1, text='2', variable=adcchoice2, command= refreshdisplay)
adccheckbutton2.pack(side=LEFT); adccheckbutton2.select()
adccheckbutton3= Checkbutton (frame1, text='3', variable=adcchoice3, command= refreshdisplay)
adccheckbutton3.pack(side=LEFT); adccheckbutton3.select()
adccheckbutton4= Checkbutton (frame1, text='4', variable=adcchoice4, command= refreshdisplay)
adccheckbutton4.pack(side=LEFT); adccheckbutton4.select()

# Selection and reading of digital input/output 
frame2=Frame(fen1, width=100, borderwidth=3, relief=SUNKEN)
frame2.grid(row=24, column=1, sticky=E)
iotext= Label(frame2, text=_('Digital outputs:'), pady=10).grid(row=5)
space= Label(frame2, text='')

butio1sunken= False
butio2sunken= False
butio3sunken= False
butio4sunken= False
butio5sunken= False
butio6sunken= False

butio1=Button(frame2,text='1', command=buto1)
butio1.grid(row=5, column=10)

butio2=Button(frame2,text='2', command=buto2)
butio2.grid(row=5, column=11)

butio3=Button(frame2,text='3', command=buto3)
butio3.grid(row=5, column=12)

butio4=Button(frame2,text='4', command=buto4)
butio4.grid(row=5, column=13)

butio5=Button(frame2,text='5', command=buto5)
butio5.grid(row=5, column=14)

butio6=Button(frame2,text='6', command=buto6)
butio6.grid(row=5, column=15)


iotext2= Label(frame2, text=_('Digital inputs:  ')).grid(row=10)

E= [Label(frame2, text=" 1 ", bg="grey"),Label(frame2, text=" 2 ", bg="grey"),Label(frame2, text=" 3 ", bg="grey"), \
     Label(frame2, text=" 4 ", bg="grey"),Label(frame2, text=" 5 ", bg="grey"), Label(frame2, text=" 6 ", bg="grey")]

for i in (0,1,2,3,4,5):
    E[i].grid(row=10, column=10+i)
    

# -----------------  Event loop   ------------------------------------------------------------------------ 

fen1.mainloop()
